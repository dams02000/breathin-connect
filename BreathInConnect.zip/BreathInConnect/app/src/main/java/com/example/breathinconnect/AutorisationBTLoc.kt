package com.example.breathinconnect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AutorisationBTLoc : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_autorisation_b_t_loc)
    }
}